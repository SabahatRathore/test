import React, { useEffect, useState } from "react";
import axios from "axios";
import todoStyles from "./todo.module.css";
import DatePicker from "react-datepicker";
import Modal from "react-modal";

import "react-datepicker/dist/react-datepicker.css";

function App() {
  const [toDo, setToDo] = useState("");
  const [ids, setIds] = useState("");
  const [idDel, setIdDel] = useState("");
  const [date, setDate] = useState(new Date());
  const [data, setData] = useState([]);
  const [dat, setDat] = useState([]);
  const [lengt, setLengt] = useState(false);
  const [val, setVal] = useState(false);
  const [sep, setSep] = useState(false);
  const [up, setUp] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const [value, setValue] = useState("");
  const [todoID, setTodoID] = useState("");

  const addData = async () => {
    if (toDo.length <= 0) {
      setLengt(true);
    } else if (toDo.length > 24) {
      setVal(true);
    } else if (!/^[A-Za-z0-9\s]+$/.test(toDo)) {
      setSep(true);
    } else {
      console.log("len", toDo.length);
      const body = {
        task: toDo,
        date: date,
        profileId:value,
      };
      const config = {
        Headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body,
      };
    

      axios
        .post(`http://localhost:5000/api/todo/todoAdd`, config)
        .then((response) => console.log("send data", response))
        .catch((err) => console.log("errors", err));
        
    showData();
      setLengt(false);
      setVal(false);
      setSep(false);
      setToDo("");
      setDate(new Date());
    }
  };

  const edit = async (id) => {
    setUp(true);
    setIds(id);
    axios
      .get(`http://localhost:5000/api/todo/todoShowId?id=${id}`)
      .then((response) => {
        setToDo(response.data.response.task);
        console.log(response);
        const dat = new Date(response.data.response.date);
        console.log(dat, "kkkkkkkkkkk");
        setDate(dat);
      });
  };

  const update = () => {
    if (toDo.length <= 0) {
      setLengt(true);
    } else if (toDo.length > 24) {
      setVal(true);
    } else if (!/^[A-Za-z0-9\s]+$/.test(toDo)) {
      setSep(true);
    } else {
      console.log("len", toDo.length);
      const body = {
        task: toDo,
        date: date,
      };
      const config = {
        Headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*",
        },
        body,
      };

      axios
        .post(`http://localhost:5000/api/todo/todoUpdate?id=${ids}`, config)
        .then((response) => console.log("send data", response))
        .catch((err) => console.log("errors", err));
      
        showData();
      setLengt(false);
      setVal(false);
      setSep(false);
      setIds("");
      setToDo("");
      setDate(new Date());
     
    }
  };
  const Modalshow = (id) => {
    setIdDel(id);
    setOpenModal(true);
  };
  const showData = () => {
    axios
      .get(`http://localhost:5000/api/todo/agTab?id=${value}`)
      .then((response) => setData(response.data.result))
      .catch((err) => console.log("errors", err));
  };

  const del = () => {
    axios
      .get(`http://localhost:5000/api/todo/todoDel?id=${idDel}`)
      .then((response) => console.log(response))
      .catch((err) => console.log("errors", err));
    showData();
    setOpenModal(false);
  };

  const cancel = () => {
    setUp(false);
    setIds("");
    setToDo("");
    setDate(new Date());
    setVal(false);
    setSep(false);
    setLengt(false);
  };
  useEffect(() => {
 getApi();
 if(value.length > 0){
  showData()
 }
  }, [value]);
  const getApi = async () => {
    await axios
      .get(`http://localhost:5000/api/profile/index`)
      .then((res) => setDat(res.data.response))
      .catch((err) => console.log(err));
  };
  return (
    <div className={todoStyles.Main}>
      <div className={todoStyles.titlediv}>
        <h1 className={todoStyles.titletxt}>ToDo</h1>
       
      </div>
      <div className={todoStyles.dropdiv}>
   
          <select
            className={todoStyles.picker2}
            value={value}
            onChange={(e) => {
              setValue(e.target.value);
              console.log(e.target.value)
            }}
          >
              <option    value="Name"  >Name</option>
           
            {dat.map((da) => (
           
              <option   key={da._id} value={da._id}  >{da.firstName}</option>
             
            
            ))}
          </select>
         
        </div>
      <div className={todoStyles.dir}>
        <div>
          <DatePicker
            className={todoStyles.picker}
            value={date}
            selected={date}
            minDate={new Date()}
            react-datepicker
            onChange={(date) => {
              setDate(date);
            }}
            placeholderText="30/12/1998"
          />
        </div>

        <div className={todoStyles.inp}>
          <input
            className={todoStyles.input}
            placeholder="Add your task"
            type="text"
            value={toDo || ""}
            name="toDo"
            onChange={(e) => setToDo(e.target.value)}
          />
        </div>
        <div>
          {!up ? (
            <button className={todoStyles.btntxt} onClick={() => addData()}>
              Add
            </button>
          ) : (
            <button className={todoStyles.btntxt} onClick={() => update()}>
              Update
            </button>
          )}
          <button className={todoStyles.btntxt1} onClick={() => cancel()}>
            Cancel
          </button>
          <div style={{ marginTop: 0, color: "red", marginLeft: -295 }}>
            {lengt && <h4>Enter your task</h4>}
            {sep && <h4>Enter task without special character</h4>}
            {val && <h4>Enter task below 24 words</h4>}
          </div>
        </div>
      </div>
      <div className={todoStyles.map}>
        <h4>
          {data &&
            data.map((data) => {
              return (
                <div
                  className={
                    data._id === ids ? todoStyles.newdivv : todoStyles.newdiv
                  }
                  key={data._id}
                >
                  <h4 className={todoStyles.txt}>{data.task}</h4>
                  <h4 className={todoStyles.dte}>
                    {new Date(data.date).toLocaleDateString()}
                  </h4>
                  <div key={data._id} className={todoStyles.btndiv}>
                    <button
                      className={todoStyles.butn}
                      onClick={() => edit(data._id)}
                    >
                      Edit
                    </button>
                    <button
                      className={todoStyles.butn2}
                      onClick={() => Modalshow(data._id)}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              );
            })}
        </h4>
        <Modal isOpen={openModal} className={todoStyles.Modal}>
          <div>
            <div className={todoStyles.modald}>
              <div className={todoStyles.mFlex}>
                <h4 className={todoStyles.pad}>Alert</h4>
                <hr className={todoStyles.hr} />
              </div>
              <h4 className={todoStyles.pad1}>
                Are you Sure you want to Delete this task?
              </h4>
              <div  className={todoStyles.b}>
                <button
                  className={todoStyles.butn}
                  onClick={() => del(data._id)}
                >
                  Yes
                </button>
                <button
                  className={todoStyles.butn2}
                  onClick={() => setOpenModal(false)}
                >
                  No
                </button>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    </div>
  );
}

export default App;
