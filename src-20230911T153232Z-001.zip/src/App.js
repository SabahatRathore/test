import React from "react";
import Todo from "../src/Todo/Todo";
import AddUser from "../src/UserProf/AddUser";
import Layout from "./layout";
import Display from "./Display/Display";
import { BrowserRouter, Switch, Routes, Route, link } from "react-router-dom";
import layStyles from "../src/App.module.css";
export default function App() {
  return (
  <div className={layStyles.appMain}> 
   <BrowserRouter> 
   <div className={layStyles.divnav}>

      <div className={layStyles.divnvbr}>
        <div className={layStyles.div1}>
     <h4>Demo Profile</h4>
        </div>
        <div className={layStyles.div2}>
      <Layout />
      </div>
      <div className={layStyles.fot}>
          <h4>My Account</h4> 
          <h4>Logout</h4> 
          <h4>Setting</h4> 
      </div>
      </div>
      <div className={layStyles.divcomp}>
      <Routes>
        <Route path="todo" element={<Todo />} />
        <Route path="Add" element={<AddUser />} />
        <Route path="Display" element={<Display />} />
      </Routes>
      </div>
      </div>
      </BrowserRouter>

</div>
 
  );
}
