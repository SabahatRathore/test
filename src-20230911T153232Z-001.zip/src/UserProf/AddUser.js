import React from "react";
import addStyles from  "./styleUser.module.css";
import { useState } from "react";
import axios from "axios";
import DatePicker from "react-datepicker";
import Modal from "react-modal";
import "react-datepicker/dist/react-datepicker.css";
import { Link, useLocation, BrowserRouter as Router  } from "react-router-dom";
import { useEffect } from "react";
export default function AddUser() {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [fatherName, setFatherName] = useState("");
  const [email, setEmail] = useState("");
  const [gender, setGender] = useState("Male");
  const [language, setLanguage] = useState([""]);
  const [province, setProvince] = useState("");
  const [dob, setDob] = useState(new Date());
  const [firstLengt, setFirstLengt] = useState(false);
  const [firstVal, setFirstVal] = useState(false);
  const [firstSep, setFirstSep] = useState(false);
  const [lastLengt, setLastLengt] = useState(false);
  const [lastVal, setLastVal] = useState(false);
  const [lastSep, setLastSep] = useState(false);
  const [fatherLengt, setFatherLengt] = useState(false);
  const [fatherVal, setFatherVal] = useState(false);
  const [fatherSep, setFatherSep] = useState(false);
  const [emailLengt, setEmailLengt] = useState(false);
  const [emailSep, setEmailSep] = useState(false);
  const [ id,setID] = useState("")
  const [openModal, setOpenModal] = useState(false);

  function useQuery() {
    return new URLSearchParams(useLocation().search);
  }
  let query = useQuery();
  
useEffect(()=>{
  setID(query.get("id"))
  if(id.length>0){}
  getProf()
},[])
const getProf = async () => {
 
 
  await axios
    .get(`http://localhost:5000/api/profile/show/?id=${ query.get("id")}`)
    .then(res => {
      setFirstName(res.data.response.firstName);
      setLastName(res.data.response.lastName);
      setFatherName(res.data.response.fatherName);
      setEmail(res.data.response.email);    
      setGender(res.data.response.gender);
      console.log("g",res.data.response.language[0]);
      setProvince(res.data.response.province);
      const dat = new Date(res.data.response.dob);
      setDob(dat)

    })
    .catch(err => console.warn(err));
};
   
const dataPush = (e)=>{
if(e)
  language.push(e.target.value)
}
const saveData = async () => {

  if (firstName.length <= 0) {
    setFirstLengt(true);
  } else if (firstName.length > 12) {
    setFirstVal(true);
  } else if (!/^[A-Za-z]+$/.test(firstName)) {
    setFirstSep(true);
  }
  else if (lastName.length <= 0) {
    setLastLengt(true);
  } else if (lastName.length > 12) {
    setLastVal(true);
  } else if (!/^[A-Za-z]+$/.test(lastName)) {
    setLastSep(true);
  }
 else if (fatherName.length <= 0) {
    setFatherLengt(true);
  } else if (fatherName.length > 20) {
    setFatherVal(true);
  } else if (!/^[A-Za-z\s]+$/.test(fatherName)) {
    setFatherSep(true);
  }
  else if (email.length <= 0) {
    setEmailLengt(true);
  } else if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
    setEmailSep(true);
  } else {
    setFirstLengt(false);
    setFirstSep(false);
    setFirstVal(false);
    setLastLengt(false);
    setLastVal(false);
    setLastSep(false);
    setFatherLengt(false);
    setFatherSep(false);
    setFatherVal(false);
    setEmailLengt(false);
    setEmailSep(false);
    
    const body = {
      firstName: firstName,
      lastName: lastName,
      fatherName: fatherName,
      email: email,
      gender: gender,
      language : language,
      province: province,
      dob: dob,
    };
    const config = {
      Headers: { "content-type": "application/json" },
      body,
    };


    await axios
    .post(`http://localhost:5000/api/profile/add`, config)
    .then((response) => console.log("datas", response))
    .catch((error) => console.log("error", error));

    window.location = '/Display';
}};
  const updateData = async () => {

    if (firstName.length <= 0) {
      setFirstLengt(true);
    } else if (firstName.length > 12) {
      setFirstVal(true);
    } else if (!/^[A-Za-z]+$/.test(firstName)) {
      setFirstSep(true);
    }
   else if (lastName.length <= 0) {
      setLastLengt(true);
    } else if (lastName.length > 12) {
      setLastVal(true);
    } else if (!/^[A-Za-z]+$/.test(lastName)) {
      setLastSep(true);
    }
    else if (fatherName.length <= 0) {
      setFatherLengt(true);
    } else if (fatherName.length > 20) {
      setFatherVal(true);
    } else if (!/^[A-Za-z\s]+$/.test(fatherName)) {
      setFatherSep(true);
    }
   else if (email.length <= 0) {
      setEmailLengt(true);
    } else if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
      setEmailSep(true);
    } else {
      setFirstLengt(false);
      setFirstSep(false);
      setFirstVal(false);
      setLastLengt(false);
      setLastVal(false);
      setLastSep(false);
      setFatherLengt(false);
      setFatherSep(false);
      setFatherVal(false);
      setEmailLengt(false);
      setEmailSep(false);
      
      const body = {
        firstName: firstName,
        lastName: lastName,
        fatherName: fatherName,
        email: email,
        gender: gender,
        language: language,
        province: province,
        dob: dob,
      };
      const config = {
        Headers: { "content-type": "application/json" },
        body,
      };


     
        await axios
          .post(
            `http://192.168.100.64:5000/api/profile/update/?id=${id}`,
            config,
          )
          .then(response => console.log('datas', response))
          .catch(error => console.log('error', error));
          window.location = '/Display';
  }};

  console.log(language)
  const clear = ()=>{
    setFirstLengt(false);
    setFirstSep(false);
    setFirstVal(false);
    setLastLengt(false);
    setLastVal(false);
    setLastSep(false);
    setFatherLengt(false);
    setFatherSep(false);
    setFatherVal(false);
    setEmailLengt(false);
    setEmailSep(false);
    setFirstName("")
    setLastName("")
    setFatherName("")
    setEmail("")
    setDob(new Date())
    setGender("Male")
    setProvince("Province")
    setOpenModal(false)
  }
  return (
    <div className={addStyles.Main}>
      <div className={addStyles.titlediv}>
        <h3 className={addStyles.titletxt}>User Profile</h3>
      </div>
      <div className={addStyles.div}>
        <div className={addStyles.indiv}>
          <div className={addStyles.txtdiv}>
            
          </div>
          <div className={addStyles.feilddiv}>
            <input
              className={addStyles.input}
              name="firstName"
              type="text"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder="Enter first Name"
            />
            <div className={addStyles.err}>
              {firstLengt && <h4>Enter your First Name</h4>}
              {firstSep && <h4>Enter FirstName without special character</h4>}
              {firstVal && <h4>Enter FirstName below 12 words</h4>}
            </div>
          </div>
        </div>
        <div className={addStyles.indiv}>
          <div className={addStyles.txtdiv}>
         
          </div>
          <div className={addStyles.feilddiv}>
            <input
              className={addStyles.input}
              name="lastName"
              type="text"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              placeholder="Enter Last Name"
            />
              <div className={addStyles.err}>
            {lastLengt && <h4>Enter your Last Name</h4>}
            {lastSep && <h4>Enter LastName without special character</h4>}
            {lastVal && <h4>Enter LarstName below 12 words</h4>}
          </div>
          </div>
        
        </div>
        <div className={addStyles.indiv}>
          <div className={addStyles.txtdiv}>
           
          </div>
          <div className={addStyles.feilddiv}>
            <input
              className={addStyles.input}
              name="fatherName"
              type="text"
              value={fatherName}
              onChange={(e) => setFatherName(e.target.value)}
              placeholder="Enter father Name"
            />
             <div className={addStyles.err}>
            {fatherLengt && <h4>Enter your Father Name</h4>}
            {fatherSep && <h4>Enter Father Name without special character</h4>}
            {fatherVal && <h4>Enter Father Name below 20 words</h4>}
          </div>
          </div>
         
        </div>
        <div className={addStyles.indiv}>
          <div className={addStyles.txtdiv}>
        
          </div>
          <div className={addStyles.feilddiv}>
            <input
              className={addStyles.input}
              name="email"
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter Email"
            />
             <div className={addStyles.err}>
            {emailLengt && <h4>Enter your Email</h4>}
            {emailSep && <h4>Enter Valid Email</h4>}
          </div>
          </div>
         
        </div>
        <div className={addStyles.indiv}>
          <div className={addStyles.txtdiv}>
        
          </div>
          <div className={addStyles.feilddiv}>
            <input
              className={addStyles.gen}
              name="gender"
              type="radio"
              value="Male"
              checked={gender === "Male"}
              onChange={(e) => setGender(e.target.value)}
            />
            Male
            <input
              className={addStyles.gen}
              name="gender"
              type="radio"
              value="Female"
              checked={gender === "Female"}
              onChange={(e) => setGender(e.target.value)}
            />
            Female
          </div>
        </div>
        <div className={addStyles.indiv}>
          <div className={addStyles.txtdiv}>
           
          </div>
          <div className={addStyles.feilddiv}>
            <input
              className={addStyles.gen}
              name="language"
              type="checkbox"
              value="English"
              onChange={(e) => setLanguage(e.target.value)}
            />
            English
            <input
              className={addStyles.gen}
              name="gender"
              type="checkbox"
              value="Urdu"
             onChange={(e) => (e.target.value)}
            />
            urdu
          </div>
        </div>

        <div className={addStyles.indiv1}>
          <div className={addStyles.txtdiv}>
         
          </div>
          <div className={addStyles.feilddiv}>
            <select
              className={addStyles.drop}
              value={province}
              onChange={(e) => setProvince(e.target.value)}
            >
              <option value="punjab"> Punjab </option>
              <option value="sindh"> Sindh </option>
              <option value="Kpk"> KpK</option>
              <option value="Bloachistan"> Bloachistan </option>
            </select>
          </div>
        </div>
        <div className={addStyles.indiv1}>
          <div className={addStyles.txtdiv}>
        
          </div>
          <div className={addStyles.feilddiv}>
            <div className={addStyles.inputfeilddiv}>
              <DatePicker
                className={addStyles.picker}
                value={dob}
                selected={dob}
                maxDate={new Date()}
                react-datepicker
                onChange={(dob) => {
                  setDob(dob);
                }}
                placeholderText="30/12/1998"
              />
            </div>
          </div>
        </div>
      </div>
      <div className={addStyles.btndiv}> 
       {id <=0 ? <button onClick={() => saveData()} type="submit" className={addStyles.butn}>
          Save
        </button> 
        : <button onClick={() => updateData()} type="submit" className={addStyles.butn}>
     Update
      </button>}
        <button onClick={() => setOpenModal(true)} type="submit" className={addStyles.btntxt1}>
          Clear
        </button>
      </div>
      <Modal isOpen={openModal} className={addStyles.Modal}>
        <div>
          <div className={addStyles.modald}>
            <div className={addStyles.mFlex}>
              <h4 className={addStyles.pad}>Alert</h4>
              <hr className={addStyles.hr} />
            </div>
            <h4 className={addStyles.pad1}>
              Are you Sure you want to Clear ?
            </h4>
            <div  className={addStyles.b}>
              <button className={addStyles.butn3} onClick={() => clear()}>
                Yes
              </button>
              <button
                className={addStyles.butn2}
                onClick={() => setOpenModal(false)}
              >
                No
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}
