import { Outlet, Link } from "react-router-dom";
import layStyles from "../src/App.module.css";
const Layout = () => {
  return (
    <div >
   
        <div className={layStyles.pad1} >
          <div className={layStyles.pad}>
            <Link to="/todo">Todo</Link>
            </div>
            <div className={layStyles.pad} >
            <Link to="/Add">Adduser</Link>
            </div>
            <div className={layStyles.pad} >
            <Link to="/Display">Display Profile </Link>
            </div>
           </div>


      <Outlet />
    </div>
  )
};

export default Layout;