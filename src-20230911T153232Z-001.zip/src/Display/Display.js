import React, { useState, useEffect } from "react";
import axios from "axios";
import dispStyles from "./dispStyles.module.css";
import Modal from "react-modal";
import { useNavigate,Link} from "react-router-dom";
export default function () {
  const [data, setData] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  const [idDel, setIdDel] = useState("");
  const navigate = useNavigate();
  const getApi = async () => {
    await axios
      .get("http://localhost:5000/api/profile/index")
      .then((res) => setData(res.data.response))
      .catch((err) => console.log(err));
  };
  const delProf = async () => {
    {
      await axios
        .get(`http://localhost:5000/api/profile/Delete/?id=${idDel}`)
        .then((res) => console.log("bbb", res))
        .catch((err) => console.log(err));
    }
    getApi();
    setOpenModal(false);
  };
  const Modalshow = (id) => {
    setIdDel(id);
    setOpenModal(true);
  };
  useEffect(() => {
    console.log("called");
    getApi();
  }, []);
  return (
    <div className={dispStyles.Maindiv}>
      <h1 className={dispStyles.titlemain}>Display</h1>
      <div>
        <div className={dispStyles.divt}>
          <div>
            <h2>Name</h2>
          </div>
          <div className={dispStyles.emaill}>
            <h2>Email</h2>
          </div>
        
        </div>
        {data &&
          data.map((data) => {
            return (
              <div className={dispStyles.divmap} key={data._id}>
                <div className={dispStyles.frstdiv}>
                  <h4>{data.firstName}</h4>
                </div>
                <div className={dispStyles.emaildiv}>
                  <h4>{data.email}</h4>
                </div>
                <div className={dispStyles.divmap}>
                  <div className={dispStyles.btndiv}>
                  <Link to={`/Add?id=${ data._id}`}>
                    <button
                      className={dispStyles.butn}
                    >
                      Edit
                    </button>
                    </Link>
                    <button
                      className={dispStyles.butn2}
                      onClick={() => Modalshow(data._id)}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
      </div>
      <Modal isOpen={openModal} className={dispStyles.Modal}>
        <div>
          <div className={dispStyles.modald}>
            <div className={dispStyles.mFlex}>
              <h4 className={dispStyles.pad}>Alert</h4>
              <hr className={dispStyles.hr} />
            </div>
            <h4 className={dispStyles.pad1}>
              Are you Sure you want to Delete this task?
            </h4>
            <div key={data._id} className={dispStyles.b}>
              <button className={dispStyles.butn} onClick={() => delProf()}>
                Yes
              </button>
              <button
                className={dispStyles.butn2}
                onClick={() => setOpenModal(false)}
              >
                No
              </button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
}
