import React from 'react'
import { useState } from 'react'

export default function AllTodo() {
    const [data,setData] = useState("")
  return (
    <div>AllTodo</div>
  )
}
