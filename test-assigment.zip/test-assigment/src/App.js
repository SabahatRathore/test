import React, { useEffect, useState } from 'react';
import Select from 'react-select'

import './App.css';

function App() {
  const [selectedOption, setSelectedOption] = useState( [
    { value: 'Manufacturing', label: 'Manufacturing' },
    { value: 'Construction materials', label: 'Construction materials' },
    { value: 'Food and Beverage', label: 'Food and Beverage' },
    { value: 'fish products', label: 'fish products' },
    { value: 'Living room', label: 'Living room' },
    { value: 'Living room', label: 'FLiving room' },
  ]); 

  const [name, setName] = useState(''); 
  const [terms, setTerms] = useState("data"); 
  const saveData =() =>{
    if(name == ""){
      alert("Please Enter name")
    } else if(selectedOption == ""){
      alert("Please select option")
    }else if(terms == ""){
      alert("Please check the terms and condtion")
    }
    else{
console.log(name,selectedOption,terms);
      localStorage.setItem('name',name);
      localStorage.setItem('selectedOption', selectedOption);
      localStorage.setItem('terms', terms);
    }
  }
  useEffect(()=>{
    var name = localStorage.getItem("name");
    var selectedOption = localStorage.getItem("selectedOption");
    var terms = localStorage.getItem("terms");
    setName(name)
    setSelectedOption(selectedOption)
    setTerms(terms)
  },[])
  return (
    <div className="App">
     
     <h4>Please enter your name and pick the Sectors you are currently involved in.</h4>
     <div style={{display:"flex",alignItems:"center",gap:"10px"}}>
     <p className='txt'>Name:</p>
        <input type='text' placeholder='Enter your name' className='inp' onChange={(e)=>setName(e)} />
     </div>
     <div style={{display:"flex",alignItems:"center",gap:"10px"}}>
     <p className='txt'>Sectors:</p>

     <Select options={selectedOption} />

     </div>
     <div className='nameView'>
      <input type="checkbox"  onChange={(e)=>setName(e)}/>
      <div className='inpview'>
     <h6 className='txt'>Agree to terms</h6>
     </div>

     </div>
     <button onClick={()=>{saveData()}} >
      save
     </button>
    </div>
  );
}

export default App;
